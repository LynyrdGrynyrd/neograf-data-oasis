"""
GrafGuard Schema for NeoGraf Materials Data Hub
Defines data structure for graphite materials R&D data
"""

from nomad.config import config
from nomad.datamodel.data import Schema
from nomad.datamodel.metainfo.annotations import ELNAnnotation, ELNComponentEnum
from nomad.metainfo import Quantity, Section, SubSection, MEnum
from nomad.datamodel.results import Results, Properties, Material


class GrafGuardGrade(Schema):
    """
    Schema for GrafGuard expandable graphite grades
    Based on NeoGraf's R&D data structure from SciNote
    """
    
    # Basic Material Info
    grade_name = Quantity(
        type=str,
        description="Grade name (e.g., GG-100, GG-200)",
        a_eln=ELNAnnotation(component=ELNComponentEnum.StringEditQuantity)
    )
    
    vendor = Quantity(
        type=str,
        description="Supplier/vendor name",
        a_eln=ELNAnnotation(component=ELNComponentEnum.StringEditQuantity)
    )
    
    country = Quantity(
        type=str,
        description="Country of origin",
        a_eln=ELNAnnotation(component=ELNComponentEnum.StringEditQuantity)
    )
    
    status = Quantity(
        type=MEnum(['R&D', 'Commercial', 'Discontinued', 'Trial']),
        description="Commercial status",
        a_eln=ELNAnnotation(component=ELNComponentEnum.EnumEditQuantity)
    )
    
    form = Quantity(
        type=MEnum(['Flake', 'Powder', 'Spherical', 'Fiber']),
        description="Physical form",
        a_eln=ELNAnnotation(component=ELNComponentEnum.EnumEditQuantity)
    )
    
    # Mesh Distribution (multiple fields for size ranges)
    mesh_plus_80 = Quantity(
        type=float,
        unit='percent',
        description="Percentage retained on +80 mesh",
        a_eln=ELNAnnotation(component=ELNComponentEnum.NumberEditQuantity)
    )
    
    mesh_80_100 = Quantity(
        type=float,
        unit='percent', 
        description="Percentage -80+100 mesh",
        a_eln=ELNAnnotation(component=ELNComponentEnum.NumberEditQuantity)
    )
    
    mesh_100_200 = Quantity(
        type=float,
        unit='percent',
        description="Percentage -100+200 mesh", 
        a_eln=ELNAnnotation(component=ELNComponentEnum.NumberEditQuantity)
    )
    
    mesh_minus_200 = Quantity(
        type=float,
        unit='percent',
        description="Percentage -200 mesh",
        a_eln=ELNAnnotation(component=ELNComponentEnum.NumberEditQuantity)
    )
    
    # Chemical Properties
    ash_content = Quantity(
        type=float,
        unit='percent',
        description="Ash content %",
        a_eln=ELNAnnotation(component=ELNComponentEnum.NumberEditQuantity)
    )
    
    sulfur_content = Quantity(
        type=float,
        unit='ppm',
        description="Sulfur content in ppm",
        a_eln=ELNAnnotation(component=ELNComponentEnum.NumberEditQuantity)
    )
    
    moisture_content = Quantity(
        type=float,
        unit='percent',
        description="Moisture content %",
        a_eln=ELNAnnotation(component=ELNComponentEnum.NumberEditQuantity)
    )
    
    ph_value = Quantity(
        type=float,
        description="pH value",
        a_eln=ELNAnnotation(component=ELNComponentEnum.NumberEditQuantity)
    )
    
    # Intercalation Properties  
    acid_concentration = Quantity(
        type=float,
        unit='percent',
        description="Acid concentration used %",
        a_eln=ELNAnnotation(component=ELNComponentEnum.NumberEditQuantity)
    )
    
    intercalation_temperature = Quantity(
        type=float,
        unit='celsius',
        description="Intercalation temperature",
        a_eln=ELNAnnotation(component=ELNComponentEnum.NumberEditQuantity)
    )
    
    intercalation_time = Quantity(
        type=float,
        unit='minute',
        description="Intercalation time in minutes", 
        a_eln=ELNAnnotation(component=ELNComponentEnum.NumberEditQuantity)
    )
    
    # Expansion Properties
    expansion_ratio = Quantity(
        type=float,
        unit='mL/g',
        description="Expansion ratio mL/g",
        a_eln=ELNAnnotation(component=ELNComponentEnum.NumberEditQuantity)
    )
    
    expansion_temperature = Quantity(
        type=float,
        unit='celsius',
        description="Expansion temperature",
        a_eln=ELNAnnotation(component=ELNComponentEnum.NumberEditQuantity)
    )
    
    dwell_time = Quantity(
        type=float,
        unit='second',
        description="Dwell time at expansion temperature",
        a_eln=ELNAnnotation(component=ELNComponentEnum.NumberEditQuantity)
    )
    
    # TGA/Thermal Properties
    tma_onset_temperature = Quantity(
        type=float,
        unit='celsius',
        description="TMA onset temperature from TGA",
        a_eln=ELNAnnotation(component=ELNComponentEnum.NumberEditQuantity)
    )
    
    weight_loss_300c = Quantity(
        type=float,
        unit='percent',
        description="Weight loss at 300°C",
        a_eln=ELNAnnotation(component=ELNComponentEnum.NumberEditQuantity)
    )
    
    residue_850c = Quantity(
        type=float,
        unit='percent',
        description="Residue at 850°C",
        a_eln=ELNAnnotation(component=ELNComponentEnum.NumberEditQuantity)
    )
    
    # Manufacturing/QC Info
    batch_number = Quantity(
        type=str,
        description="Manufacturing batch number",
        a_eln=ELNAnnotation(component=ELNComponentEnum.StringEditQuantity)
    )
    
    production_date = Quantity(
        type=str,
        description="Production date",
        a_eln=ELNAnnotation(component=ELNComponentEnum.DateTimeEditQuantity)
    )
    
    lot_size = Quantity(
        type=float,
        unit='kg',
        description="Lot size in kg",
        a_eln=ELNAnnotation(component=ELNComponentEnum.NumberEditQuantity)
    )
    
    # Notes and Comments
    notes = Quantity(
        type=str,
        description="Additional notes or observations",
        a_eln=ELNAnnotation(component=ELNComponentEnum.RichTextEditQuantity)
    )
    
    def normalize(self, archive, logger):
        """
        Custom normalization logic
        """
        super().normalize(archive, logger)
        
        # Ensure material results are populated
        if not archive.results:
            archive.results = Results()
        if not archive.results.material:
            archive.results.material = Material()
            
        # Set material name from grade_name
        if self.grade_name:
            archive.results.material.material_name = self.grade_name
            
        # Add custom properties for searching
        if not archive.results.properties:
            archive.results.properties = Properties()
            
        # Make key properties searchable
        if self.expansion_ratio:
            archive.results.properties.mechanical = []
            # Add expansion ratio as searchable property


# Register the schema
m_package.__init_metainfo__()