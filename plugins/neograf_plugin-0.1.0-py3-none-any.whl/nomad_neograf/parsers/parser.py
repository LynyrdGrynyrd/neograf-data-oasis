"""
LECO TGA Parser for NeoGraf NOMAD Plugin
Parses thermogravimetric analysis data from LECO instruments
"""

import pandas as pd
import numpy as np
from nomad.datamodel import EntryArchive
from nomad.parsing import MatchingParser
from nomad.units import ureg
from nomad.datamodel.metainfo.annotations import ELNAnnotation
from nomad.metainfo import Quantity, Section, SubSection
import re


class TGAData(Section):
    """Section for TGA measurement data"""
    
    temperature = Quantity(
        type=np.float64,
        shape=['*'],
        unit='celsius',
        description="Temperature values from TGA",
        a_eln=ELNAnnotation(component='PlotlyGraph')
    )
    
    weight_percent = Quantity(
        type=np.float64,
        shape=['*'],
        unit='percent', 
        description="Weight percentage values",
        a_eln=ELNAnnotation(component='PlotlyGraph')
    )
    
    time = Quantity(
        type=np.float64,
        shape=['*'],
        unit='minute',
        description="Time values in minutes",
        a_eln=ELNAnnotation(component='PlotlyGraph')
    )
    
    onset_temperature = Quantity(
        type=float,
        unit='celsius',
        description="Onset temperature of weight loss",
        a_eln=ELNAnnotation(component='NumberEditQuantity')
    )
    
    total_weight_loss = Quantity(
        type=float,
        unit='percent',
        description="Total weight loss percentage",
        a_eln=ELNAnnotation(component='NumberEditQuantity')
    )
    
    residue_at_850c = Quantity(
        type=float,
        unit='percent',
        description="Residue remaining at 850°C",
        a_eln=ELNAnnotation(component='NumberEditQuantity')
    )


class LECOTGAParser(MatchingParser):
    """Parser for LECO TGA CSV/Excel files"""
    
    def __init__(self):
        super().__init__(
            name='parsers/leco_tga',
            code_name='LECO_TGA_Parser',
            code_homepage='https://github.com/neograf/nomad-neograf-plugin',
            supported_compressions=['gz', 'bz2', 'xz']
        )
    
    def parse(self, mainfile: str, archive: EntryArchive, logger):
        """
        Parse LECO TGA data files
        
        Expected formats:
        - CSV with columns: Time(min), Temp(°C), Weight(%)
        - Excel with similar structure
        """
        
        logger.info(f'Parsing LECO TGA file: {mainfile}')
        
        try:
            # Try reading as CSV first
            if mainfile.endswith('.csv'):
                df = pd.read_csv(mainfile)
            elif mainfile.endswith(('.xlsx', '.xls')):
                df = pd.read_excel(mainfile)
            else:
                logger.error(f'Unsupported file format: {mainfile}')
                return
                
            # Clean column names (remove spaces, standardize)
            df.columns = df.columns.str.strip().str.lower()
            
            # Map common column name variations
            column_mapping = {
                'time': ['time', 'time(min)', 'time_min', 'minutes'],
                'temperature': ['temp', 'temperature', 'temp(°c)', 'temp_c', 'temperature(°c)'],
                'weight': ['weight', 'weight(%)', 'weight_percent', 'wt%', 'mass%']
            }
            
            # Find actual column names
            actual_columns = {}
            for standard_name, variations in column_mapping.items():
                for col in df.columns:
                    if any(var in col for var in variations):
                        actual_columns[standard_name] = col
                        break
            
            if len(actual_columns) < 3:
                logger.warning(f'Could not identify all required columns in {mainfile}')
                logger.info(f'Available columns: {list(df.columns)}')
                # Try to use first 3 columns as time, temp, weight
                if len(df.columns) >= 3:
                    actual_columns = {
                        'time': df.columns[0],
                        'temperature': df.columns[1], 
                        'weight': df.columns[2]
                    }
                else:
                    return
            
            # Extract data arrays
            time_data = df[actual_columns['time']].values
            temp_data = df[actual_columns['temperature']].values  
            weight_data = df[actual_columns['weight']].values
            
            # Remove NaN values
            valid_indices = ~(np.isnan(time_data) | np.isnan(temp_data) | np.isnan(weight_data))
            time_data = time_data[valid_indices]
            temp_data = temp_data[valid_indices]
            weight_data = weight_data[valid_indices]
            
            # Calculate derived values
            onset_temp = self.calculate_onset_temperature(temp_data, weight_data)
            total_loss = weight_data[0] - weight_data[-1] if len(weight_data) > 0 else 0
            residue_850 = self.calculate_residue_at_temperature(temp_data, weight_data, 850)
            
            # Create TGA data section
            tga_data = TGAData()
            tga_data.time = time_data * ureg.minute
            tga_data.temperature = temp_data * ureg.celsius  
            tga_data.weight_percent = weight_data * ureg.percent
            tga_data.onset_temperature = onset_temp * ureg.celsius
            tga_data.total_weight_loss = total_loss * ureg.percent
            tga_data.residue_at_850c = residue_850 * ureg.percent
            
            # Add to archive
            if not hasattr(archive, 'data'):
                archive.data = TGAData()
            archive.data = tga_data
            
            # Set metadata
            archive.metadata.entry_name = f"TGA Analysis - {mainfile.split('/')[-1]}"
            
            logger.info(f'Successfully parsed TGA data with {len(time_data)} data points')
            
        except Exception as e:
            logger.error(f'Error parsing {mainfile}: {str(e)}')
            
    def calculate_onset_temperature(self, temp_data, weight_data, threshold=0.5):
        """
        Calculate onset temperature where weight loss begins
        threshold: minimum weight loss percentage to detect onset
        """
        if len(weight_data) < 2:
            return 0
            
        # Calculate derivative (rate of weight loss)
        dwdt = np.gradient(weight_data, temp_data)
        
        # Find where derivative exceeds threshold (negative because weight decreases)
        onset_indices = np.where(np.abs(dwdt) > threshold)[0]
        
        if len(onset_indices) > 0:
            return temp_data[onset_indices[0]]
        else:
            return temp_data[0]
    
    def calculate_residue_at_temperature(self, temp_data, weight_data, target_temp):
        """
        Calculate residue percentage at specific temperature
        """
        if len(temp_data) == 0:
            return 0
            
        # Find closest temperature point
        temp_diff = np.abs(temp_data - target_temp)
        closest_idx = np.argmin(temp_diff)
        
        return weight_data[closest_idx]
    
    def is_a_measurement_file(self, path):
        """Check if file is a TGA measurement file"""
        if not (path.endswith('.csv') or path.endswith('.xlsx') or path.endswith('.xls')):
            return False
            
        # Check filename patterns
        tga_patterns = [
            r'tga.*\.csv$',
            r'.*_tga.*\.',
            r'thermograv.*\.',
            r'leco.*\.',
            r'.*thermal.*\.'
        ]
        
        filename = path.lower()
        return any(re.search(pattern, filename) for pattern in tga_patterns)